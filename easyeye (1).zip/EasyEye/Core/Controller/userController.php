<?php
	class userController extends Eye {
		public function reg()
		{
			
			 
//			$JSON=$this->I("json");
//			$phone=$JSON->phone;
//			$password=$JSON->password;
//			$modb="s_user";
//			 $db=$this->M($modb);
//			 $user=$db->Find("Mobile", $phone);
//			$user->password="lvchuan";
//			$user->save();
//			exit();
            $JSON=$this->I("json");
			$phone=$JSON->phone;		
            $password=$JSON->password;
			$this->mylog($JSON->phone);
			$this->mylog($phone);
		    $modb="s_user";
			$db=$this->M($modb);
//			echo $db;
	        $db->mobile=$phone;
	        $db->password=$password;
	        $db->Id=$phone;
	        //var_dump($db->values);
			$sql='select * from s_user where Mobile = "'.$phone.'";';	
		    if(!$row=$db->Query($sql)){
			    if($db->Add()){
					$result['state']=SUCCESS;
				    echo json_encode($result);
			    }
			    else{
				$result['state']=USER_EXISTS;
				echo json_encode($result);
			    }
			}
			
		}
		public function log()
		{
			$JSON=$this->I("json");
			$mobile=$JSON->phone;
			$password=$JSON->password;
			$sql='select * from s_user where Mobile = '.$mobile.' and password='.$password.';';
			$Modelname="s_user";
			$db=$this->M($Modelname);	
	        if(!$row=$db->Query($sql)){
	        	$res['state']=LOGIN_ERROR;
				echo json_encode($res);
	        }
	        else{
	        	
//	        	if($row['password']==$password){
//	        	echo $row;
//	        	   $user=array();
//		           $user['username']=$row['Username'];
//		           $user['id']=$row['Id'];
//		           $user['type']=$row['Type'];
//		           $user['time']=$row['Time'];
//		           $user['mobile']=$row['Mobile'];
//		           $user['wechat']=$row['Wechat'];
//		           $user['credit']=$row['Credit'];
//		           $user['provid']=$row['Provid'];
//		           $user['image']=$row['Image'];
//		           $user['token']=$username;
//返回token
				$res['token'] = $mobile;
                   $res['state']=SUCCESSFUL;
                  $res['info'] = $row;
                   echo json_encode($res);
		          	
		       }
//		       else{
//		       	$res['state']=LOGIN_ERROR;
//				 echo json_encode($res);
//	          }
			//}
		}
		
		public function getcode()
       { 
    	
        $JSON=$this->I("json");
	    $pn=$JSON->phone;
	    $code=$this->randStr(4,'NUMBER');
	    $this->message($pn,$code,$tempID);
		$result["code"]=$code;
		echo json_encode($result);
//  	$this->Assign("title","hello");
//  	$this->Assign("content","name");
//  	
//  	$this->Display("login");
//	   $mongodb=new MongoDB($config);
//	   $mongodb->insert(reg());
	   }
	   //获取某个地域的商家
	   public function getsellerinfo(){
	   	    $JSON=$this->I("json");
	   	    $page=$JSON->page;
	   	    $n=$JSON->n;
	   	    $kind=$JSON->kind;
	   	if($kind==0){
			$x=$JSON->x;
			$y=$JSON->y;
	   		
	   	}
	   	if($kind==1){
	   		$position=$JSON->position;
	   		$offset = $n*($page-1);
	   		$sql='select * from s_store where Address like "%'.$position.'%" limit '.$offset.','.$n.';';
			$Modelname="s_store";
			$db=$this->M($Modelname);
	        $row=$db->Query($sql);
	        $users=array();
	        for($i=0;$i<$n;$i++){
	        	//是否验证信息if($row['password']==$password){
	        	$user=array();
		        $user['id']=$row[$i]['Id'];
		        $user['Name']=$row[$i]['Name'];
		        $user['Uid']=$row[$i]['Uid'];
		        $user['Phone']=$row[$i]['Phone'];
		        $user['mobile']=$row[$i]['Mobile'];
		        $user['wechat']=$row[$i]['Wechat'];
		        $user['created']=$row[$i]['Created'];
		        $user['Address']=$row[$i]['Address'];
		        $user['x']=$row[$i]['X'];
		        $user['y']=$row[$i]['Y'];
		        $user['credit']=$row[$i]['Credit'];
		        $users[$i]= $user;		
		        }
		        echo json_encode($users);
		    }
	    }
//	   //获取某个商家商品s_goods
//	   public function getsellerProduct(){
//	   	$JSON=$this->I("json");
//	   	$sid=$JSON->sid;
//      $sql='select * from s_goods where Sid= '.$sid.';';	
//      $Modelname="s_goods";
//		$db=$this->M($Modelname);
//	    $row=$db->Query($sql);
////	    for($i=0;$i<$n;$i++){
////	        	//是否验证信息if($row['password']==$password){
////	        	$user=array();
////		        $user['id']=$row[$i]['Id'];
////		        $user['name']=$row[$i]['Name'];
////		        $user['sid']=$row[$i]['Sid'];
////		        $user['bid']=$row[$i]['Bid'];
////		        $user['price']=$row[$i]['Price'];
////		        $user['beyond_price']=$row[$i]['Beyond_price'];
////		        $user['deposit']=$row[$i]['Deposit'];
////		        $user['status']=$row[$i]['Status'];
////		        $user['x']=$row[$i]['X'];
////		        $user['y']=$row[$i]['Y'];
////		        echo json_encode($user);		
////		    }
//     echo json_encode($row);
//		}
//	   $dbLink=connectMysqli();
//	if(!$result=$dbLink->query($sql)){
//		exitSend(DB_NOT_FIND);
//	}else{
//		$row=$result->fetch_assoc();
//		$sql='select * from p_image where pid= '.$id.';';
//		$iResult=$dbLink->query($sql);
//		$i=0;
//		while($irow=$iResult->fetch_assoc())
//		{
//			$imgs['imgPath'.$i]=IMGPATH.$irow['imgPath'];
//			$i++;
//		}
//		$row['imgGroup']=$imgs;
//		print_r(json_encode($row));
//	}
//}
//获取某个地域的商品s_good 中缺少Address
//      public function getareaproductrinfo(){
//	   	    $JSON=$this->I("json");
//	   	    $position=$JSON->position;
//	   	    $n=$JSON->n;
//	   	    $page=$JSON->page;
//	   	    $kind=$JSON->kind;
//	   	if($kind==0){
//	   		//$position['x']
//	   		
//	   	}
//	   	if($kind==1){
//	   		$sql='select * from s_goods where Address like "%'.$position.'%";';
//			$Modelname="s_goods";
//			$db=$this->M($Modelname);
//	        $row=$db->Query($sql);
//	        for($i=0;$i<$n;$i++){
//	        	//是否验证信息if($row['password']==$password){
//	        	$user=array();
//		        $user['id']=$row[$i]['Id'];
//		        $user['catid']=$row[$i]['Catid'];
//		        $user['sid']=$row[$i]['Sid'];
//		        $user['bid']=$row[$i]['Bid'];
//		        $user['price']=$row[$i]['Price'];
//		        $user['beyond_price']=$row[$i]['Beyond_price'];
//		        $user['deposit']=$row[$i]['Deposit'];
//		        $user['status']=$row[$i]['Status'];
//		        $user['x']=$row[$i]['x'];
//		        $user['y']=$row[$i]['y'];
//		        $user['address']=$row[$i]['Address'];
//		        echo json_encode($user);		
//		        }
//		    }
//	    }

//获取商品详情s_goods 和s_good_cat
        public function getdetailinfo (){
        	$JSON=$this->I("json");
			$id=$JSON->id;
		    $modb="s_goods";
			$db=$this->M($modb);
			$sql='select * from s_goods where id = '.$id.';';
			if($db->Query($sql)){
			 $row=$db->Query($sql);
	        	//是否验证信息if($row['password']==$password){
	        	$user=array();
		        $user['id']=$row['Id'];
		        $user['catid']=$row['Catid'];
		     
		        $photoinfo=array();
		        $sql='select * from s_photo where Gid = "'.$user['catid'].'";';
		        $dbnm="s_photo";
			    $db=$this->M($dbnm);	
			    $res=$db->Query($sql);
			    $photoinfo['id']=$res['Id'];
			    $photoinfo['gid']=$res['Gid'];
			    $photoinfo['url']=$res['Url'];
			    $photoinfo['isCover']=$res['IsCover'];
			    
		        $user['sid']=$row['Sid'];
		        $user['bid']=$row['Bid'];
		        $user['price']=$row['Price'];
		        $user['beyond_price']=$row['Beyond_price'];
		        $user['deposit']=$row['Deposit'];
		        $user['status']=$row['Status'];
		        $user['x']=$row['x'];
		        $user['y']=$row['y'];
		        $user['photoinfo']=$photoinfo;
		        echo json_encode($user);		
		        }
		       }
	

////提交订单
//  public function submitOrder(){
//      $JSON=$this->I("json");
//			$gid=$JSON->gid;
//			$n=$JSON->n;
//			$msg=$JSON->msg;
//	        $token=$JSON->token;
//	        $bid=$JSON->bid;
//			$addressid=$JSON->addressid;
//			$uid=$JSON->uid;
//			$oid=$JSON->oid;
//			
//			$modb="s_goods_cat";
//			$db=$this->M($modb);
//			$db->id=$gid;
//
//			if($db->Add()){
//				$modb="s_user";
//			$db=$this->M($modb);
//			$db->id=$uid;
//		    if($db->Add()){
//			
//		    $modb="s_order";
//		    $db=$this->M($modb);
//		    $db->Id=$oid;
//			$db->Gid=$gid;
//	        $db->n=$n;
//	        $db->msg=$msg;
//	        $db->addressid=$addressid;
//	        $db->Bid=$bid;
//	        $db->Uid=$uid;
//	        
//	        //判断token
//			if($db->Add()){
//				
//					$result['state']=SUCCESS;
//				    echo json_encode($result);
//			    }
//			    else{
//			    	
//				$result['state']=SYS_ERROR;
//				echo json_encode($result);
//			    }
//			}
//			else{
//				$result['state']=SYS_ERROR;
//				echo json_encode($result);
//			}
//			}
//			}
			

    	
    	
//	$sql='insert into  (uid,address,name,price,aprice,remark,ctime,phone) values('.$uid.',"'.$address.'","'.$name.'",'.$price.','.$aprice.',"'.$remark.'",'.$ctime.',"'.$phone.'");';
//
//	$dbLink=connectMysqli();
//	if(!$result=$dbLink->query($sql)){
//		exitSend(DB_INSERT_ERROR);
//	}
//	$oid=$dbLink->insert_id;
//	foreach( $products as $product){
//		$pid=$product['pid'];
//		$number=$product['number'];
//		$sql='insert into o_products values('.$oid.','.$pid.','.$number.');';
//		if(!$oresult=$dbLink->query($sql)){
//			//�˴�Ӧɾ��ող���Ķ�������Ϣ
//			exitSend(DB_INSERT_ERROR);
//		}
//				
//	}
//	print_r(json_encode(array('OID'=>$oid)));

	
}
////获取订单
//function getOrder($uid){
//	$dbLink=connectMysqli();
//	$sql='select *from `order` where id='.$uid.';';
//	if(!$result=$dbLink->query($sql)){
//		exitSend(DB_NOT_FIND);
//	}
//	$products=array();
//	$order=$result->fetch_assoc();
//	$oid=$order['id'];
//	
//	$sql='select *from o_products where id='.$oid.';';
//	if(!$oResult=$dbLink->query($sql)){
//		exitSend(DB_NOT_FIND);
//	}
//	while($prow=$oResult->fetch_assoc()){
//		$pid=$prow['pid'];
//		$sql='select name,price from products where id='.$pid.';';
//		if(!$pResult=$dbLink->query($sql)){
//		    exitSend(DB_NOT_FIND);
//			}
//		
//		$product[]=$pid;
//		$product[]=$pResult['name'];
//		$product[]=$pResult['price'];
//		
//		
//		$sql='select imgPath from p_image where id='.$pid.' limit 1;';
//		if(!$iResult=$dbLink->query($sql)){
//		    exitSend(DB_NOT_FIND);
//		}
//		$pathrow=$iResult->fetch_assoc();
//		
//		$products[]=$pathrow;
//		
//	}
//	$order['products']=$products;
//  echo json_encode($order);
// }
 


?>