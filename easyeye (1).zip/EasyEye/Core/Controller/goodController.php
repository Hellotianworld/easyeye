<?php
	class goodController extends Eye{
		public function getdetailinfo (){
        	$JSON=$this->I("json");
			$id=$JSON->id;
		    $modb="s_goods";
			$db=$this->M($modb);
			$sql='select * from s_goods where id = ?';	
			$row=$db->Query($sql,array($id));
	        	//是否验证信息if($row['password']==$password){
	        	$user=array();
		        $user['id']=$row[0]['Id'];
		        $user['catid']=$row[0]['Catid'];
		       
		        
		     
		        $photoinfo=array();
		        $sql='select * from s_photo where Gid = "'.$user['catid'].'";';
		        $dbnm="s_photo";
			    $db=$this->M($dbnm);	
			    $res=$db->Query($sql);
			    $photoinfo['id']=$res[0]['Id'];
			    $photoinfo['gid']=$res[0]['Gid'];
			    $photoinfo['url']=$res[0]['Url'];
			    $photoinfo['isCover']=$res[0]['IsCover'];
			    
		        $user['sid']=$row[0]['Sid'];
		        $user['bid']=$row[0]['Bid'];
		        $user['price']=$row[0]['Price'];
		        $user['beyond_price']=$row[0]['Beyond_price'];
		        $user['deposit']=$row[0]['Deposit'];
		        $user['status']=$row[0]['Status'];
		        $user['x']=$row[0]['x'];
		        $user['y']=$row[0]['y'];
		        $user['photoinfo']=$photoinfo;
		        echo json_encode($user);		
		        }
		public function getsellerProduct(){
	   	$JSON=$this->I("json");
	   	$sid=$JSON->sid;
        $sql='select * from s_goods where Sid= '.$sid.';';	
        $Modelname="s_goods";
		$db=$this->M($Modelname);
	    $row=$db->Query($sql);
//	    for($i=0;$i<$n;$i++){
//	        	//是否验证信息if($row['password']==$password){
//	        	$user=array();
//		        $user['id']=$row[$i]['Id'];
//		        $user['name']=$row[$i]['Name'];
//		        $user['sid']=$row[$i]['Sid'];
//		        $user['bid']=$row[$i]['Bid'];
//		        $user['price']=$row[$i]['Price'];
//		        $user['beyond_price']=$row[$i]['Beyond_price'];
//		        $user['deposit']=$row[$i]['Deposit'];
//		        $user['status']=$row[$i]['Status'];
//		        $user['x']=$row[$i]['X'];
//		        $user['y']=$row[$i]['Y'];
//		        echo json_encode($user);		
//		    }
       echo json_encode($row);
		}
		//获取某个地域的商品s_good 中缺少Address
	    public function getareaproductrinfo(){
	   	    $JSON=$this->I("json");
	   	    $page=$JSON->page;
	   	    $n=$JSON->n;
	   	    $kind=$JSON->kind;
	   	if($kind==0){
			$x=$JSON->x;
			$y=$JSON->y;
	   		
	   	}
	   	if($kind==1){
	   		$position=$JSON->position;
	   		$users=array();
	   		$offset = $n*($page-1);
	   		$sql='select * from s_goods where Address like "%'.$position.'%" limit '.$offset.','.$n.';';
			$Modelname="s_goods";
			$db=$this->M($Modelname);
	        $row=$db->Query($sql);
	        for($i=0;$i<$n;$i++){
	        	//是否验证信息if($row['password']==$password){
	        	$user=array();
		        $user['id']=$row[$i]['Id'];
		        $user['catid']=$row[$i]['Catid'];
		        $user['sid']=$row[$i]['Sid'];
		        $user['bid']=$row[$i]['Bid'];
		        $user['price']=$row[$i]['Price'];
		        $user['beyond_price']=$row[$i]['Beyond_price'];
		        $user['deposit']=$row[$i]['Deposit'];
		        $user['status']=$row[$i]['Status'];
		        $user['x']=$row[$i]['x'];
		        $user['y']=$row[$i]['y'];
		        $user['address']=$row[$i]['Address'];
		        $users[$i]=$user;		
		        }
		    }
		    echo json_encode($users);
	    }
	}

?>