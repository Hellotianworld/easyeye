<?php
	class orderController extends Eye {
public function submitOrder(){
        $JSON=$this->I("json");
			$gid=$JSON->gid;
			$n=$JSON->n;
			$msg=$JSON->msg;
	        $token=$JSON->token;
	        $bid=$JSON->bid;
			$addressid=$JSON->addressid;
			$uid=$JSON->uid;
			$oid=$JSON->oid;
			
			$modb="s_goods_cat";
			$db=$this->M($modb);
			$db->id=$gid;

			if($db->Add()){
				$modb="s_user";
			$db=$this->M($modb);
			$db->id=$uid;
		    if($db->Add()){
			
		    $modb="s_order";
		    $db=$this->M($modb);
		    $db->Id=$oid;
			$db->Gid=$gid;
	        $db->n=$n;
	        $db->msg=$msg;
	        $db->addressid=$addressid;
	        $db->Bid=$bid;
	        $db->Uid=$uid;
	        
	        //判断token
			if($db->Add()){
				
					$result['state']=SUCCESS;
				    echo json_encode($result);
			    }
			    else{
			    	
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			    }
			}
			else{
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			}
			}
			}
		
		public function evaluteorder()
    { 
    	 $JSON=$this->I("json");
            $id=$JSON->orderid;

			$token=$JSON->token;
			$msg=$JSON->msg;
			$modb="s_order";
			$db=$this->M($modb);
			
			
			$sql='INSERT INTO s_order(msg)  VALUE("'.$msg.'")  where id = "'.$id.'";';
	        //判断token
			if($db->Query($sql)){
				
					$result['state']=SUCCESS;
				    echo json_encode($result);
			    }
			    else{
			    	
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			   
			}
	}
}
?>