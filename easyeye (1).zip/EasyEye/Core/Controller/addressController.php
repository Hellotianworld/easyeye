<?php
	class addressController extends Eye
{
	
	public function addaddress()
    { 
    	 $JSON=$this->I("json");

		    $address=$JSON->address;
			$token=$JSON->token;
			$id=$this->randstr(6,NUMBER);
			echo $id;
			$phone=$JSON->phone;
			
			$modb="S_address";
			$db=$this->M($modb);
			$db->address=$address;
			$db->id=$id;
			$db->phone=$phone;
	        //判断token
			if($db->Add()){
				
					$result['addressid']=$id;
				    echo json_encode($result);
			    }
			    else{
			    	
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			   
			}
		
		
    }
    public function deleteaddress()
    { 
    	 $JSON=$this->I("json");
            $id=$JSON->addressid;

			$token=$JSON->token;
			
			$modb="s_address";
			$db=$this->M($modb);
			$db->id=$id;
	        //判断token
			if($db->delete()){
				
					$result['state']=SUCCESS;
				    echo json_encode($result);
			    }
			    else{
			    	
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			   
			}
	}
	public function getaddresslist()
    { 
    	 $JSON=$this->I("json");
            $id=$JSON->addressid;

			$token=$JSON->token;
			
			$modb="s_address";
			$db=$this->M($modb);
			$db->id=$id;
	        //判断token
			if($db->delete()){
				
					$result['state']=SUCCESS;
				    echo json_encode($result);
			    }
			    else{
			    	
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			   
			}
	}
	public function cancelorder()
    { 
    	 $JSON=$this->I("json");
            $id=$JSON->orderid;

			$token=$JSON->token;
			
			$modb="s_order";
			$db=$this->M($modb);
			$db->id=$id;
			
	        //判断token
			if($db->delete()){
				
					$result['state']=SUCCESS;
				    echo json_encode($result);
			    }
			    else{
			    	
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			   
			}
	}
	public function evaluteorder()
    { 
    	 $JSON=$this->I("json");
            $id=$JSON->orderid;

			$token=$JSON->token;
			$msg=$JSON->msg;
			$modb="s_order";
			$db=$this->M($modb);
			$db->id=$id;
			$db->msg=$msg;
			
	        //判断token
			if($db->add()){
				
					$result['state']=SUCCESS;
				    echo json_encode($result);
			    }
			    else{
			    	
				$result['state']=SYS_ERROR;
				echo json_encode($result);
			   
			}
	}
}

 

?>