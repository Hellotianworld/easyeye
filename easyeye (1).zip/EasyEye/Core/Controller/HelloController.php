<?php


class HelloController extends Eye
{
	
	public function Hello()
    { 
    	 
    	$this->Assign("content","name");
    	
    	$this->Display("login");
//	   $mongodb=new MongoDB($config);
//	   $mongodb->insert(reg());
		
		
		
    }
	
}
 
?>