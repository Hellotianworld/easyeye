

<?php 
//系统的配置文件，数据库配置	
	$cacheconfig=array();
	$dataconfig=array("client"=>array("host"=>"127.0.0.1","root"=>"root","password"=>"12345678","port"=>"3306","dbname"=>"database"));
	$viewconfig=array();
	$autoconfig=array();
	$ecyconfig=array("cache"=>$cacheconfig,"data"=>$dataconfig,"view"=>$viewconfig,"auto"=>$autoconfig);
	
    define ('SUCCESSFUL','10000');             
    define ('PARAMETER_FEW','10001');
    define ('SYS_ERROR','10002');
    define ('USER_EXISTS','10003');
    define ('LOGIN_ERROR','10004');
    
	return $ecyconfig;
	?>