<?php
/* Smarty version 3.1.30, created on 2016-10-15 15:25:15
  from "C:\AppServ\www\EasyEye\Core\view\User\login.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5801d9db7f6537_48202725',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fd85394a5eee9674515e1511b316f9c7fc444d2f' => 
    array (
      0 => 'C:\\AppServ\\www\\EasyEye\\Core\\view\\User\\login.html',
      1 => 1476516307,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5801d9db7f6537_48202725 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title> <?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 </title>
	</head>
	<body>
		<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

	</body>
</html>
<?php }
}
