<?php
//整个程序的执行体
/********
 * 这里设置全局使用的函数，自定义控制器只需要调用就行。
 * 把这个设置成工厂类
 * 这里由于namespace的原因不方便加载扩展的的库，所以干脆直接取消namespace的作用
 * 
 *********/ 
//namespace Eye;
#region 数据格式定义
define("FAIL", "failed");
define("SUCCESS", "success");
#regionend 数据格式定义


class Eye
{
	
	private $smarty;
	
	
	public static $m_classSource;	//类全局
	public static $m_instance;		//类的实例化对象
	public static $m_class;			//当前控制器调用的class
	public static $m_method;   		//当前控制器调用的method
	public static $m_smartydir;
	public static $m_valuestack;	//值栈
	
	public static $session_state=FALSE;
	
	public static $session;
	//注册全局函数
	public function __construct()
	{
	}
	//启动函数
	public static function Start()
	{
		spl_autoload_register('Eye::EyeAutoload');
        set_exception_handler('Eye::appException');
		
		$Request_url=$_SERVER['REQUEST_URI'];
		//这里使用一个
		$split1= split("php", $Request_url);
        $result=split("/", $split1[1]);
	    self::$m_class=$result[1]."Controller";
		self::$m_method=$result[2];
		self::$m_smartydir=$result[1];
		//如果有必要使用的缓存文件，使用的是hash值代表文件名字
		$filepath=crc32(self::$m_class.self::$m_method);
		self::Instance(self::$m_class, self::$m_method);
		

	}
	//过滤器
	public function I($name)
	{
	//控制器获取的内容应该为json数据。或者是get，post。
	 if(!isset(self::$m_valuestack["json"]))
	 	{
	   	self::$m_valuestack["json"]=file_get_contents("php://input");
	 	}
	 if($name!="json")
	 	{
	 		if(isset($_GET[$name]))
			return $this->Safe($_GET[$name]);
			if(isset($_POST[$name]))
			return $this->Safe($_POST[$name]);
	 	}
	 else 
	 	{	
	 			
	 		
			return  json_decode(self::$m_valuestack["json"]);
	 	}	  
	}
	
	public function Assign($key, $value) {
	require_once $_SERVER['DOCUMENT_ROOT'].'/EasyEye/Eye/Utils/ViewPlugins/Smarty/Smarty.class.php';
	$this->smarty=$this->smarty==null?new Smarty:$this->smarty;
	$this->smarty->compile_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Core/ViewCache/";
	$this->smarty->config_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Eye/Utils/ViewPlugins/Smarty/configs/";
	$this->smarty->cache_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Core/ViewCache/";
	$this->smarty->left_delimiter='<{';
	$this->smarty->right_delimiter='}>';
	$this->smarty->assign($key, $value);
		
	}
	
	public function __set($key, $value){
		
	}
	
	public function Display($netfile){
	require_once $_SERVER['DOCUMENT_ROOT'].'/EasyEye/Eye/Utils/ViewPlugins/Smarty/Smarty.class.php';
	$this->smarty=$this->smarty==null?new Smarty:$this->smarty;
//	$this->smarty->template_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Core/view/User/";
//	$this->smarty->compile_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Eye/Utils/ViewPlugins/Smarty/templates_c/";
//	$this->smarty->config_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Eye/Utils/ViewPlugins/Smarty/configs/";
//	$this->smarty->cache_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Eye/Utils/ViewPlugins/Smarty/cache/";
//	$this->smarty->left_delimiter='<{';
//	$this->smarty->right_delimiter='}>';
	$this->smarty->template_dir= $_SERVER['DOCUMENT_ROOT']."/EasyEye/Core/view/".self::$m_smartydir;
	$this->smarty->display($netfile.VIEWEXT); 		
	}
	
	
	//数据库操作
	public  function M($modelname)
	{
		//获取到modelname。这个时候可以直接调用。 
		$db=new BaseModel($modelname);
		return $db;
	}
	//输出内容
	public function Show($words)
	{
		echo $words;
	
	}
	
	//重定向
	public function R($url)
	{
		header("location:$url");
	}
	//返回数据
	public static function Back($state,$message,$body)
	{
		$map["state"]=$state;
		$map["message"]=$message;
		$map["body"]=$body;
		echo json_encode($map);
	}
	//SESSION管理
	public function S($key)
	{
		if(self::$session_state==FALSE)
		{	
			self::$session_state=TRUE;
			session_start();
		}
		
		if(!isset($_SESSION[$key]))
		{
			return NULL;
		}
		else
		{
			return $_SESSION[$key];
		}
	}
	
	public function AddS($key,$value)
	{
		if(self::$session_state==FALSE)
		{	
			self::$session_state=TRUE;
			session_start();
		}
		$_SESSION[$key]=$value;
	}
	
	public function SetSession($key, $value){
		if(self::$session==null){
			self::$session=new Session(session_id());
			self::$session->set($key, $value);
		}else {
			self::$session->set($key, $value);
		}
	}
	
	public function GetSession($key){
		if(self::$session==null){
			self::$session=new Session(session_id());
			self::$session->set($key);
		}else {
			self::$session->set($key);
		}
	}
	
	
	public function DestoryS()
	{
		
		session_destroy();
	}
	
	//自动加载autoload
	public static function EyeAutoload($classname)
	{
		
		$funcdir=array("Config","JSON","Sql","Sql/Cache","Sql/Model","Sql/Model/Model","Utils/Session");
		if(!isset(self::$m_classSource[$classname]))
		{
		    //设置策略，去搜索空间中的类。
			if(strstr($classname, "Controller"))
			{
				$str=DIR."Core/"."Controller/".$classname.EXT;
				if(!file_exists($str))
				{
					self::Back(FAIL, "不存在该控制器", NULL);
					return;
				}
				include DIR."Core/"."Controller/".$classname.EXT;
			}
			else if(strstr($classname, ".Func."))	//这里加载Func插件
			{
				$str=DIR."Core/"."Func/".$classname.EXT;
				if(!file_exists($str))
				{
					self::Back(FAIL, "不存在该插件", NULL);
					return;
				}
				include DIR."Core/"."Controller/".$classname.EXT;
				
			}
			else 
			{
				foreach($funcdir as $dir)
				{
					$str=DIR."Eye/"."$dir/".$classname.EXT;
					if(file_exists($str))
					{
						include $str;
					}
				}
			}
			
			  self::$m_classSource[$classname]=$classname;
		}
	}
	//实例化对象
	public static function Instance($class,$method) 
	{
		if(!isset(self::$m_instance[$class.$method]))
		{
		$newclass=new $class;
		$reflectionMethod = new \ReflectionMethod($class, $method);
        $reflectionMethod->invoke($newclass);
	    self::$m_instance[$class.$method]=$reflectionMethod;
		self::$m_instance[$class]=$newclass;
		}
		
	}
	
	//错误处理
	  static public function appException($e) {
        $error = array();
        $error['message']   =   $e->getMessage();
        $trace              =   $e->getTrace();
        if('E'==$trace[0]['function']) {
            $error['file']  =   $trace[0]['file'];
            $error['line']  =   $trace[0]['line'];
        }else{
            $error['file']  =   $e->getFile();
            $error['line']  =   $e->getLine();
        }
        $error['trace']     =   $e->getTraceAsString();
        // 发送404信息
        header('HTTP/1.1 404 Not Found');
        header('Status:404 Not Found');
    }
	//数据过滤,这里只过滤出html元素特殊字符
	function Safe($str)
	{
     	return htmlspecialchars($str);

    }
    //生成验证码
    function randStr($len=6,$format='ALL'){ 
  
        switch($format){ 
            case 'ALL'://生成包含数字和字母的验证码 
            $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; break; 
            case 'CHAR'://仅生成包含字母的验证码 
            $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; break; 
            case 'NUMBER'://仅生成包含数字的验证码 
            $chars='0123456789'; break; 
            default : 
            $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; break; 
        } 
        $string=''; 
        while(strlen($string)<$len) 
            $string.=substr($chars,(mt_rand()%strlen($chars)),1); 
        return $string; 
    }

	public function message($pn, $code, $tempId){
		 require_once "Utils/message/message.php";
		 $mes=new message($pn, $code);
		 $mes->initiallise();
		 $mes->templateId();
	}
	
	public function mylog($info){
		$myfile = fopen("log.txt", "a+") or die("Unable to open file!");
		fwrite($myfile, time().":".$info."\n");
		fclose($myfile);
		}
		
	public function token($token) {
		return $token;
	}
	
	
    
}
?>

