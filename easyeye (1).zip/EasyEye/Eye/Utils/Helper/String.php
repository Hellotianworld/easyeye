<?php 
/**
 * 字符串处理类
 * 
 */
 class String
 {
 	public static function Replace(){
 		
 	}
	
	public static function Look(){
		
	}
	
	public static function Contains($str, $key){
		if(strstr($str, $key)){
			return TRUE;
		}
		else {
			return FALSE;
		}
		
	}
	
 }


?>