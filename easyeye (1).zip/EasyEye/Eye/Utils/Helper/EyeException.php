<?php
//namespace EyeException;
 
class EyeException extends  \Exception
{  
	public function __construct()
	{
		
	}
	
}

?>