<?php 
	class CSession extends  Session
	{
		$config;
		public function innit()
		{}
	  
		
		
	}
	
	?>