<?php
/**
 *  set beecloud pay main params
 *
 */

const APP_ID = 'bae3a71a-b05b-4acd-bb1c-3a3ae3122b47';
const APP_SECRET = 'b3f09a3f-85cb-40a2-926b-b8994965764c';
//test_secret for sandbox
const TEST_SECRET = ' ';
const MASTER_SECRET = ' ';

const RETURN_URL="";
const WEBHOOK="";
