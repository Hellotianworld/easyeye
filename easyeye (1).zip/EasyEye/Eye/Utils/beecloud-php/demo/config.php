<?php
/**
 *  set beecloud pay main params
 *
 */

const APP_ID = 'c5d1cba1-5e3f-4ba0-941d-9b0a371fe719';
const APP_SECRET = '39a7a518-9ac8-4a9e-87bc-7885f33cf18c';
//test_secret for sandbox
const TEST_SECRET = '4bfdd244-574d-4bf3-b034-0c751ed34fee';
const MASTER_SECRET = 'e14ae2db-608c-4f8b-b863-c8c18953eef2';